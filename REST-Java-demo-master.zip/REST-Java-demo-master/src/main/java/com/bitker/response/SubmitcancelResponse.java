package com.bitker.response;

/**
 * @Author lumingxing
 * @Date 2018/12/06
 * @Time 17:15
 */

public class SubmitcancelResponse {


    /**
     * status : ok
     * data : 59378
     */

    private String status;
    private String data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

}
